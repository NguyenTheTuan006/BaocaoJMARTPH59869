# JPMART - Ứng dụng quản lý siêu thị mini

## Mô tả
JPMART là ứng dụng Android được phát triển để quản lý siêu thị mini chuyên cung cấp các sản phẩm xuất xứ Nhật Bản. Ứng dụng giúp thay thế việc quản lý bằng Excel với hệ thống số hóa hiện đại, bảo mật và dễ sử dụng.

## Tính năng chính

### 🔐 Quản lý người dùng và phân quyền
- **Đăng nhập bắt buộc**: Tất cả người dùng phải đăng nhập để sử dụng
- **Phân quyền theo vai trò**:
  - **ADMIN**: Toàn quyền truy cập tất cả chức năng
  - **STAFF**: Chỉ có quyền quản lý sản phẩm, khách hàng, hóa đơn (không xem thống kê)

### 📊 Quản lý nghiệp vụ
- **Quản lý danh mục sản phẩm**: Thêm, sửa, xóa danh mục
- **Quản lý sản phẩm**: Thông tin chi tiết, tồn kho, xuất xứ Nhật Bản
- **Quản lý khách hàng**: Thông tin cá nhân, lịch sử mua hàng
- **Quản lý nhân viên**: Chỉ ADMIN mới có quyền
- **Quản lý hóa đơn**: Tạo, cập nhật, theo dõi trạng thái

### 📈 Thống kê và báo cáo (Chỉ ADMIN)
- **Thống kê doanh thu**: Theo khoảng thời gian
- **Top sản phẩm bán chạy**: Sản phẩm được mua nhiều nhất
- **Top khách hàng**: Khách hàng chi tiêu nhiều nhất

## Công nghệ sử dụng

- **Android View**: Giao diện người dùng
- **Room Database**: Cơ sở dữ liệu SQLite
- **LiveData & ViewModel**: Quản lý dữ liệu và lifecycle
- **Navigation Component**: Điều hướng giữa các màn hình
- **Material Design**: Giao diện hiện đại, đẹp mắt

## Cài đặt và chạy

### Yêu cầu hệ thống
- Android Studio Arctic Fox trở lên
- Android SDK 24+ (Android 7.0)
- Java 11

### Các bước cài đặt
1. Clone repository về máy
2. Mở project trong Android Studio
3. Sync Gradle files
4. Chạy ứng dụng trên thiết bị hoặc emulator

### Tài khoản mặc định
- **Username**: admin
- **Password**: admin123
- **Vai trò**: ADMIN

## Cấu trúc project

```
app/src/main/java/fpoly/nttuanph59869/baocaoph59869/
├── model/           # Các entity (User, Product, Customer, Invoice...)
├── dao/            # Data Access Objects
├── database/       # Room Database và Converters
├── repository/     # Repository pattern
├── viewmodel/      # ViewModels
├── fragment/       # Các Fragment
├── MainActivity.java
└── LoginActivity.java
```

## Hướng dẫn sử dụng

### 1. Đăng nhập
- Mở ứng dụng
- Nhập username và password
- Click "ĐĂNG NHẬP"

### 2. Sử dụng chức năng
- Sử dụng navigation drawer (menu bên trái) để chuyển đổi giữa các chức năng
- Dashboard hiển thị tổng quan hệ thống
- Các chức năng quản lý được nhóm theo từng mục

### 3. Phân quyền
- **ADMIN**: Có thể truy cập tất cả chức năng
- **STAFF**: Không thể xem thống kê và quản lý nhân viên

## Phát triển tiếp theo

### Các chức năng đang được phát triển
- [ ] Quản lý sản phẩm chi tiết
- [ ] Quản lý khách hàng
- [ ] Quản lý hóa đơn
- [ ] Thống kê doanh thu
- [ ] Báo cáo top sản phẩm
- [ ] Báo cáo top khách hàng

### Cải tiến tương lai
- [ ] Quét mã vạch sản phẩm
- [ ] In hóa đơn
- [ ] Backup dữ liệu
- [ ] Đồng bộ đa thiết bị
- [ ] Giao diện web admin

## Đóng góp

Dự án này được phát triển cho mục đích học tập và nghiên cứu. Mọi đóng góp đều được chào đón!

## Liên hệ

- **Tác giả**: Sinh viên FPT Polytechnic
- **Môn học**: Báo cáo thực tập
- **Năm**: 2024

## License

Dự án này được phát hành dưới giấy phép MIT. Xem file LICENSE để biết thêm chi tiết.

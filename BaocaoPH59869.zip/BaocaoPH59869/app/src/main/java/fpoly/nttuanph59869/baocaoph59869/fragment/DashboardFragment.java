package fpoly.nttuanph59869.baocaoph59869.fragment;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import fpoly.nttuanph59869.baocaoph59869.R;
import fpoly.nttuanph59869.baocaoph59869.viewmodel.DashboardViewModel;

public class DashboardFragment extends Fragment {
    private static final String TAG = "DashboardFragment";
    private DashboardViewModel viewModel;
    private TextView tvTotalProducts, tvTotalCustomers, tvTotalInvoices, tvTotalRevenue;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_dashboard, container, false);
        
        try {
            initViews(view);
            setupViewModel();
            observeData();
        } catch (Exception e) {
            Log.e(TAG, "Error initializing DashboardFragment", e);
            // Set default values if there's an error
            setDefaultValues();
        }
        
        return view;
    }

    private void initViews(View view) {
        tvTotalProducts = view.findViewById(R.id.tvTotalProducts);
        tvTotalCustomers = view.findViewById(R.id.tvTotalCustomers);
        tvTotalInvoices = view.findViewById(R.id.tvTotalInvoices);
        tvTotalRevenue = view.findViewById(R.id.tvTotalRevenue);
    }

    private void setupViewModel() {
        try {
            viewModel = new ViewModelProvider(this).get(DashboardViewModel.class);
        } catch (Exception e) {
            Log.e(TAG, "Error setting up ViewModel", e);
            setDefaultValues();
        }
    }

    private void observeData() {
        if (viewModel == null) {
            setDefaultValues();
            return;
        }

        try {
            viewModel.getTotalProducts().observe(getViewLifecycleOwner(), count -> {
                if (count != null) {
                    tvTotalProducts.setText(String.valueOf(count));
                } else {
                    tvTotalProducts.setText("0");
                }
            });

            viewModel.getTotalCustomers().observe(getViewLifecycleOwner(), count -> {
                if (count != null) {
                    tvTotalCustomers.setText(String.valueOf(count));
                } else {
                    tvTotalCustomers.setText("0");
                }
            });

            viewModel.getTotalInvoices().observe(getViewLifecycleOwner(), count -> {
                if (count != null) {
                    tvTotalInvoices.setText(String.valueOf(count));
                } else {
                    tvTotalInvoices.setText("0");
                }
            });

            viewModel.getTotalRevenue().observe(getViewLifecycleOwner(), revenue -> {
                if (revenue != null) {
                    tvTotalRevenue.setText(String.format("%,.0f VNĐ", revenue));
                } else {
                    tvTotalRevenue.setText("0 VNĐ");
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "Error observing data", e);
            setDefaultValues();
        }
    }

    private void setDefaultValues() {
        try {
            if (tvTotalProducts != null) tvTotalProducts.setText("0");
            if (tvTotalCustomers != null) tvTotalCustomers.setText("0");
            if (tvTotalInvoices != null) tvTotalInvoices.setText("0");
            if (tvTotalRevenue != null) tvTotalRevenue.setText("0 VNĐ");
        } catch (Exception e) {
            Log.e(TAG, "Error setting default values", e);
        }
    }
}

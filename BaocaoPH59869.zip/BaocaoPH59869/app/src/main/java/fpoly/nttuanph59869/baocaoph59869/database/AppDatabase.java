package fpoly.nttuanph59869.baocaoph59869.database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

import fpoly.nttuanph59869.baocaoph59869.dao.CategoryDao;
import fpoly.nttuanph59869.baocaoph59869.dao.CustomerDao;
import fpoly.nttuanph59869.baocaoph59869.dao.InvoiceDao;
import fpoly.nttuanph59869.baocaoph59869.dao.InvoiceDetailDao;
import fpoly.nttuanph59869.baocaoph59869.dao.ProductDao;
import fpoly.nttuanph59869.baocaoph59869.dao.UserDao;
import fpoly.nttuanph59869.baocaoph59869.model.Category;
import fpoly.nttuanph59869.baocaoph59869.model.Customer;
import fpoly.nttuanph59869.baocaoph59869.model.Invoice;
import fpoly.nttuanph59869.baocaoph59869.model.InvoiceDetail;
import fpoly.nttuanph59869.baocaoph59869.model.Product;
import fpoly.nttuanph59869.baocaoph59869.model.User;

@Database(entities = {
        User.class,
        Category.class,
        Product.class,
        Customer.class,
        Invoice.class,
        InvoiceDetail.class
}, version = 1, exportSchema = false)
@TypeConverters({Converters.class})
public abstract class AppDatabase extends RoomDatabase {

    private static AppDatabase instance;

    public abstract UserDao userDao();
    public abstract CategoryDao categoryDao();
    public abstract ProductDao productDao();
    public abstract CustomerDao customerDao();
    public abstract InvoiceDao invoiceDao();
    public abstract InvoiceDetailDao invoiceDetailDao();

    public static synchronized AppDatabase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(
                    context.getApplicationContext(),
                    AppDatabase.class,
                    "jpmart_database"
            ).fallbackToDestructiveMigration()
             .build();
        }
        return instance;
    }
}

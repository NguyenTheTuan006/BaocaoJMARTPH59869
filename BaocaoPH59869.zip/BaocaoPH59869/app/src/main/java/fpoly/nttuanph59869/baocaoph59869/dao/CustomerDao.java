package fpoly.nttuanph59869.baocaoph59869.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import fpoly.nttuanph59869.baocaoph59869.model.Customer;

@Dao
public interface CustomerDao {
    @Insert
    void insert(Customer customer);

    @Update
    void update(Customer customer);

    @Delete
    void delete(Customer customer);

    @Query("SELECT * FROM customers WHERE isActive = 1")
    LiveData<List<Customer>> getAllActiveCustomers();

    @Query("SELECT * FROM customers WHERE id = :id")
    Customer getCustomerById(int id);

    @Query("SELECT * FROM customers WHERE name LIKE '%' || :searchQuery || '%' AND isActive = 1")
    LiveData<List<Customer>> searchCustomers(String searchQuery);

    @Query("SELECT * FROM customers WHERE phone LIKE '%' || :phone || '%' AND isActive = 1")
    LiveData<List<Customer>> searchCustomersByPhone(String phone);

    @Query("SELECT * FROM customers WHERE isActive = 1 ORDER BY totalSpent DESC LIMIT :limit")
    LiveData<List<Customer>> getTopCustomers(int limit);

    @Query("UPDATE customers SET totalSpent = totalSpent + :amount WHERE id = :customerId")
    void updateTotalSpent(int customerId, double amount);

    @Query("SELECT COUNT(*) FROM customers WHERE isActive = 1")
    LiveData<Integer> getTotalCustomerCount();
}

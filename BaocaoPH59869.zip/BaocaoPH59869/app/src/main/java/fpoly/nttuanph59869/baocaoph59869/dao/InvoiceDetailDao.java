package fpoly.nttuanph59869.baocaoph59869.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import fpoly.nttuanph59869.baocaoph59869.model.InvoiceDetail;

@Dao
public interface InvoiceDetailDao {
    @Insert
    void insert(InvoiceDetail invoiceDetail);

    @Update
    void update(InvoiceDetail invoiceDetail);

    @Delete
    void delete(InvoiceDetail invoiceDetail);

    @Query("SELECT * FROM invoice_details WHERE invoiceId = :invoiceId")
    LiveData<List<InvoiceDetail>> getInvoiceDetailsByInvoice(int invoiceId);

    @Query("SELECT * FROM invoice_details WHERE productId = :productId")
    LiveData<List<InvoiceDetail>> getInvoiceDetailsByProduct(int productId);

    @Query("SELECT SUM(quantity) FROM invoice_details WHERE productId = :productId")
    LiveData<Integer> getTotalQuantitySoldByProduct(int productId);

    @Query("SELECT productId, SUM(quantity) as totalQuantity FROM invoice_details GROUP BY productId ORDER BY totalQuantity DESC LIMIT :limit")
    LiveData<List<ProductSales>> getTopSellingProducts(int limit);

    @Query("SELECT customerId, SUM(finalAmount) as totalAmount FROM invoices WHERE status = 'COMPLETED' GROUP BY customerId ORDER BY totalAmount DESC LIMIT :limit")
    LiveData<List<CustomerSales>> getTopCustomers(int limit);

    // Custom classes for complex queries
    public static class ProductSales {
        public int productId;
        public int totalQuantity;
    }

    public static class CustomerSales {
        public int customerId;
        public double totalAmount;
    }
}

package fpoly.nttuanph59869.baocaoph59869.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import fpoly.nttuanph59869.baocaoph59869.model.Category;

@Dao
public interface CategoryDao {
    @Insert
    void insert(Category category);

    @Update
    void update(Category category);

    @Delete
    void delete(Category category);

    @Query("SELECT * FROM categories WHERE isActive = 1")
    LiveData<List<Category>> getAllActiveCategories();

    @Query("SELECT * FROM categories WHERE id = :id")
    Category getCategoryById(int id);

    @Query("SELECT * FROM categories WHERE name LIKE '%' || :searchQuery || '%' AND isActive = 1")
    LiveData<List<Category>> searchCategories(String searchQuery);
}

package fpoly.nttuanph59869.baocaoph59869.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import fpoly.nttuanph59869.baocaoph59869.model.User;

@Dao
public interface UserDao {
    @Insert
    void insert(User user);

    @Update
    void update(User user);

    @Delete
    void delete(User user);

    @Query("SELECT * FROM users WHERE username = :username AND password = :password AND isActive = 1 LIMIT 1")
    User login(String username, String password);

    @Query("SELECT * FROM users WHERE isActive = 1")
    LiveData<List<User>> getAllActiveUsers();

    @Query("SELECT * FROM users WHERE role = 'STAFF' AND isActive = 1")
    LiveData<List<User>> getAllActiveStaff();

    @Query("SELECT * FROM users WHERE id = :id")
    User getUserById(int id);

    @Query("SELECT * FROM users WHERE username = :username")
    User getUserByUsername(String username);
}

package fpoly.nttuanph59869.baocaoph59869.viewmodel;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import fpoly.nttuanph59869.baocaoph59869.repository.CustomerRepository;
import fpoly.nttuanph59869.baocaoph59869.repository.InvoiceRepository;
import fpoly.nttuanph59869.baocaoph59869.repository.ProductRepository;

public class DashboardViewModel extends AndroidViewModel {
    private ProductRepository productRepository;
    private CustomerRepository customerRepository;
    private InvoiceRepository invoiceRepository;

    public DashboardViewModel(Application application) {
        super(application);
        productRepository = new ProductRepository(application);
        customerRepository = new CustomerRepository(application);
        invoiceRepository = new InvoiceRepository(application);
    }

    public LiveData<Integer> getTotalProducts() {
        return productRepository.getTotalProductCount();
    }

    public LiveData<Integer> getTotalCustomers() {
        return customerRepository.getTotalCustomerCount();
    }

    public LiveData<Integer> getTotalInvoices() {
        return invoiceRepository.getTotalInvoiceCount();
    }

    public LiveData<Double> getTotalRevenue() {
        return invoiceRepository.getTotalRevenue();
    }
}

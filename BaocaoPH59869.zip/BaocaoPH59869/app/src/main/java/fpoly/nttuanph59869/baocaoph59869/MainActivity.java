package fpoly.nttuanph59869.baocaoph59869;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import com.google.android.material.navigation.NavigationView;

import fpoly.nttuanph59869.baocaoph59869.fragment.CategoriesFragment;
import fpoly.nttuanph59869.baocaoph59869.fragment.DashboardFragment;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private String userRole;
    private String userName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Check if user is logged in
        if (!isLoggedIn()) {
            startLoginActivity();
            return;
        }

        initViews();
        setupNavigation();
        loadUserInfo();
        setupNavigationHeader();
        
        // Load default fragment
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new DashboardFragment())
                    .commit();
            navigationView.setCheckedItem(R.id.nav_dashboard);
        }
    }

    private void initViews() {
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }

    private void setupNavigation() {
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, findViewById(R.id.toolbar),
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        navigationView.setNavigationItemSelectedListener(this);
    }

    private void loadUserInfo() {
        SharedPreferences prefs = getSharedPreferences("JPMART_PREFS", MODE_PRIVATE);
        userRole = prefs.getString("ROLE", "");
        userName = prefs.getString("FULL_NAME", "");
    }

    private void setupNavigationHeader() {
        View headerView = navigationView.getHeaderView(0);
        TextView tvUserName = headerView.findViewById(R.id.tvUserName);
        tvUserName.setText(userName);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        Fragment fragment = null;

        if (id == R.id.nav_dashboard) {
            fragment = new DashboardFragment();
        } else if (id == R.id.nav_categories) {
            fragment = new CategoriesFragment();
        } else if (id == R.id.nav_products) {
            // TODO: Load ProductsFragment
            showComingSoon();
            return true;
        } else if (id == R.id.nav_customers) {
            // TODO: Load CustomersFragment
            showComingSoon();
            return true;
        } else if (id == R.id.nav_staff) {
            if (!userRole.equals("ADMIN")) {
                showAccessDenied();
                return true;
            }
            // TODO: Load StaffFragment
            showComingSoon();
            return true;
        } else if (id == R.id.nav_invoices) {
            // TODO: Load InvoicesFragment
            showComingSoon();
            return true;
        } else if (id == R.id.nav_revenue) {
            if (!userRole.equals("ADMIN")) {
                showAccessDenied();
                return true;
            }
            // TODO: Load RevenueFragment
            showComingSoon();
            return true;
        } else if (id == R.id.nav_top_products) {
            if (!userRole.equals("ADMIN")) {
                showAccessDenied();
                return true;
            }
            // TODO: Load TopProductsFragment
            showComingSoon();
            return true;
        } else if (id == R.id.nav_top_customers) {
            if (!userRole.equals("ADMIN")) {
                showAccessDenied();
                return true;
            }
            // TODO: Load TopCustomersFragment
            showComingSoon();
            return true;
        } else if (id == R.id.nav_profile) {
            // TODO: Load ProfileFragment
            showComingSoon();
            return true;
        } else if (id == R.id.nav_logout) {
            logout();
            return true;
        }

        if (fragment != null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .commit();
        }

        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    private void showAccessDenied() {
        Toast.makeText(this, "Bạn không có quyền truy cập chức năng này", Toast.LENGTH_SHORT).show();
    }

    private void showComingSoon() {
        Toast.makeText(this, "Chức năng đang được phát triển", Toast.LENGTH_SHORT).show();
    }

    private void logout() {
        SharedPreferences prefs = getSharedPreferences("JPMART_PREFS", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.clear();
        editor.apply();

        startLoginActivity();
    }

    private boolean isLoggedIn() {
        SharedPreferences prefs = getSharedPreferences("JPMART_PREFS", MODE_PRIVATE);
        return prefs.getBoolean("IS_LOGGED_IN", false);
    }

    private void startLoginActivity() {
        Intent intent = new Intent(this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}
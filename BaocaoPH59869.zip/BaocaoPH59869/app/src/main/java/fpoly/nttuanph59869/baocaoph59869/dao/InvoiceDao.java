package fpoly.nttuanph59869.baocaoph59869.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.Date;
import java.util.List;

import fpoly.nttuanph59869.baocaoph59869.model.Invoice;

@Dao
public interface InvoiceDao {
    @Insert
    void insert(Invoice invoice);

    @Update
    void update(Invoice invoice);

    @Delete
    void delete(Invoice invoice);

    @Query("SELECT * FROM invoices ORDER BY invoiceDate DESC")
    LiveData<List<Invoice>> getAllInvoices();

    @Query("SELECT * FROM invoices WHERE id = :id")
    Invoice getInvoiceById(int id);

    @Query("SELECT * FROM invoices WHERE customerId = :customerId ORDER BY invoiceDate DESC")
    LiveData<List<Invoice>> getInvoicesByCustomer(int customerId);

    @Query("SELECT * FROM invoices WHERE staffId = :staffId ORDER BY invoiceDate DESC")
    LiveData<List<Invoice>> getInvoicesByStaff(int staffId);

    @Query("SELECT * FROM invoices WHERE invoiceDate BETWEEN :startDate AND :endDate ORDER BY invoiceDate DESC")
    LiveData<List<Invoice>> getInvoicesByDateRange(Date startDate, Date endDate);

    @Query("SELECT SUM(finalAmount) FROM invoices WHERE invoiceDate BETWEEN :startDate AND :endDate AND status = 'COMPLETED'")
    LiveData<Double> getTotalRevenueByDateRange(Date startDate, Date endDate);

    @Query("SELECT COUNT(*) FROM invoices WHERE invoiceDate BETWEEN :startDate AND :endDate AND status = 'COMPLETED'")
    LiveData<Integer> getInvoiceCountByDateRange(Date startDate, Date endDate);

    @Query("SELECT * FROM invoices WHERE status = :status ORDER BY invoiceDate DESC")
    LiveData<List<Invoice>> getInvoicesByStatus(String status);

    @Query("SELECT COUNT(*) FROM invoices WHERE status = 'COMPLETED'")
    LiveData<Integer> getTotalInvoiceCount();

    @Query("SELECT SUM(finalAmount) FROM invoices WHERE status = 'COMPLETED'")
    LiveData<Double> getTotalRevenue();
}

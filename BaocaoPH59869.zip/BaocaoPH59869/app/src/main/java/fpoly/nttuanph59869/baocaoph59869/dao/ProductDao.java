package fpoly.nttuanph59869.baocaoph59869.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import fpoly.nttuanph59869.baocaoph59869.model.Product;

@Dao
public interface ProductDao {
    @Insert
    void insert(Product product);

    @Update
    void update(Product product);

    @Delete
    void delete(Product product);

    @Query("SELECT * FROM products WHERE isActive = 1")
    LiveData<List<Product>> getAllActiveProducts();

    @Query("SELECT * FROM products WHERE categoryId = :categoryId AND isActive = 1")
    LiveData<List<Product>> getProductsByCategory(int categoryId);

    @Query("SELECT * FROM products WHERE id = :id")
    Product getProductById(int id);

    @Query("SELECT * FROM products WHERE name LIKE '%' || :searchQuery || '%' AND isActive = 1")
    LiveData<List<Product>> searchProducts(String searchQuery);

    @Query("SELECT * FROM products WHERE stockQuantity < :threshold AND isActive = 1")
    LiveData<List<Product>> getLowStockProducts(int threshold);

    @Query("UPDATE products SET stockQuantity = stockQuantity - :quantity WHERE id = :productId")
    void updateStock(int productId, int quantity);

    @Query("SELECT * FROM products WHERE isActive = 1 ORDER BY stockQuantity ASC LIMIT :limit")
    LiveData<List<Product>> getTopSellingProducts(int limit);

    @Query("SELECT COUNT(*) FROM products WHERE isActive = 1")
    LiveData<Integer> getTotalProductCount();
}

package fpoly.nttuanph59869.baocaoph59869;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textview.MaterialTextView;

import fpoly.nttuanph59869.baocaoph59869.model.User;
import fpoly.nttuanph59869.baocaoph59869.repository.UserRepository;

public class LoginActivity extends AppCompatActivity {
    private TextInputEditText etUsername, etPassword;
    private MaterialButton btnLogin;
    private MaterialTextView tvError;
    private View progressBar;
    private UserRepository userRepository;
    private boolean isDatabaseReady = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Check if user is already logged in
        if (isLoggedIn()) {
            startMainActivity();
            return;
        }

        initViews();
        setupListeners();
        initializeDatabase();
    }

    private void initViews() {
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        tvError = findViewById(R.id.tvError);
        progressBar = findViewById(R.id.progressBar);
    }

    private void setupListeners() {
        btnLogin.setOnClickListener(v -> attemptLogin());
    }

    private void initializeDatabase() {
        userRepository = new UserRepository(getApplication());
        
        // Show initial message
        showError("Đang khởi tạo cơ sở dữ liệu...");
        
        // Initialize database and create default admin asynchronously
        new Thread(() -> {
            try {
                // Wait a bit for database to be ready
                Thread.sleep(500);
                
                // Check if admin user exists, if not create one
                User adminUser = userRepository.getUserByUsername("admin");
                if (adminUser == null) {
                    runOnUiThread(() -> showError("Đang tạo tài khoản admin mặc định..."));
                    
                    User newAdmin = new User("admin", "admin123", "Administrator", "admin@jpmart.com", "0123456789", "ADMIN");
                    userRepository.insert(newAdmin);
                    // Wait a bit more for insert to complete
                    Thread.sleep(300);
                    
                    runOnUiThread(() -> showError("Đã tạo tài khoản admin thành công!"));
                    Thread.sleep(1000);
                }
                
                // Mark database as ready
                runOnUiThread(() -> {
                    isDatabaseReady = true;
                    hideError();
                    Toast.makeText(LoginActivity.this, "Sẵn sàng đăng nhập!", Toast.LENGTH_SHORT).show();
                });
                
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> {
                    showError("Lỗi khởi tạo cơ sở dữ liệu: " + e.getMessage());
                });
            }
        }).start();
    }

    private void attemptLogin() {
        if (!isDatabaseReady) {
            showError("Đang khởi tạo cơ sở dữ liệu, vui lòng đợi...");
            return;
        }

        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            showError("Vui lòng nhập đầy đủ thông tin");
            return;
        }

        showLoading(true);
        hideError();

        // Perform login in background thread
        new Thread(() -> {
            try {
                User user = userRepository.login(username, password);
                
                runOnUiThread(() -> {
                    showLoading(false);
                    
                    if (user != null) {
                        // Save login session
                        saveLoginSession(user);
                        startMainActivity();
                    } else {
                        showError("Tên đăng nhập hoặc mật khẩu không đúng");
                    }
                });
                
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> {
                    showLoading(false);
                    showError("Lỗi đăng nhập: " + e.getMessage());
                });
            }
        }).start();
    }

    private void saveLoginSession(User user) {
        SharedPreferences prefs = getSharedPreferences("JPMART_PREFS", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt("USER_ID", user.getId());
        editor.putString("USERNAME", user.getUsername());
        editor.putString("FULL_NAME", user.getFullName());
        editor.putString("ROLE", user.getRole());
        editor.putBoolean("IS_LOGGED_IN", true);
        editor.apply();
    }

    private boolean isLoggedIn() {
        SharedPreferences prefs = getSharedPreferences("JPMART_PREFS", MODE_PRIVATE);
        return prefs.getBoolean("IS_LOGGED_IN", false);
    }

    private void startMainActivity() {
        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private void showLoading(boolean show) {
        progressBar.setVisibility(show ? View.VISIBLE : View.GONE);
        btnLogin.setEnabled(!show);
    }

    private void showError(String message) {
        tvError.setText(message);
        tvError.setVisibility(View.VISIBLE);
    }

    private void hideError() {
        tvError.setVisibility(View.GONE);
    }
}

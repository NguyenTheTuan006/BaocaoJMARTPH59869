package fpoly.nttuanph59869.baocaoph59869.model;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

@Entity(tableName = "invoice_details",
        foreignKeys = {
            @ForeignKey(entity = Invoice.class, parentColumns = "id", childColumns = "invoiceId"),
            @ForeignKey(entity = Product.class, parentColumns = "id", childColumns = "productId")
        })
public class InvoiceDetail {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private int invoiceId;
    private int productId;
    private int quantity;
    private double unitPrice;
    private double totalPrice;

    public InvoiceDetail() {
    }

    public InvoiceDetail(int invoiceId, int productId, int quantity, double unitPrice) {
        this.invoiceId = invoiceId;
        this.productId = productId;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
        this.totalPrice = quantity * unitPrice;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getInvoiceId() {
        return invoiceId;
    }

    public void setInvoiceId(int invoiceId) {
        this.invoiceId = invoiceId;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
        this.totalPrice = this.quantity * this.unitPrice;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
        this.totalPrice = this.quantity * this.unitPrice;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }
}

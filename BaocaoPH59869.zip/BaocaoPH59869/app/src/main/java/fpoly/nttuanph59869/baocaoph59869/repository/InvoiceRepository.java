package fpoly.nttuanph59869.baocaoph59869.repository;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.Date;
import java.util.List;

import fpoly.nttuanph59869.baocaoph59869.dao.InvoiceDao;
import fpoly.nttuanph59869.baocaoph59869.database.AppDatabase;
import fpoly.nttuanph59869.baocaoph59869.model.Invoice;

public class InvoiceRepository {
    private InvoiceDao invoiceDao;

    public InvoiceRepository(Application application) {
        AppDatabase database = AppDatabase.getInstance(application);
        invoiceDao = database.invoiceDao();
    }

    public void insert(Invoice invoice) {
        new InsertInvoiceAsyncTask(invoiceDao).execute(invoice);
    }

    public void update(Invoice invoice) {
        new UpdateInvoiceAsyncTask(invoiceDao).execute(invoice);
    }

    public void delete(Invoice invoice) {
        new DeleteInvoiceAsyncTask(invoiceDao).execute(invoice);
    }

    public LiveData<List<Invoice>> getAllInvoices() {
        return invoiceDao.getAllInvoices();
    }

    public Invoice getInvoiceById(int id) {
        try {
            return invoiceDao.getInvoiceById(id);
        } catch (Exception e) {
            return null;
        }
    }

    public LiveData<List<Invoice>> getInvoicesByCustomer(int customerId) {
        return invoiceDao.getInvoicesByCustomer(customerId);
    }

    public LiveData<List<Invoice>> getInvoicesByStaff(int staffId) {
        return invoiceDao.getInvoicesByStaff(staffId);
    }

    public LiveData<List<Invoice>> getInvoicesByDateRange(Date startDate, Date endDate) {
        return invoiceDao.getInvoicesByDateRange(startDate, endDate);
    }

    public LiveData<Double> getTotalRevenueByDateRange(Date startDate, Date endDate) {
        return invoiceDao.getTotalRevenueByDateRange(startDate, endDate);
    }

    public LiveData<Integer> getInvoiceCountByDateRange(Date startDate, Date endDate) {
        return invoiceDao.getInvoiceCountByDateRange(startDate, endDate);
    }

    public LiveData<List<Invoice>> getInvoicesByStatus(String status) {
        return invoiceDao.getInvoicesByStatus(status);
    }

    public LiveData<Integer> getTotalInvoiceCount() {
        return invoiceDao.getTotalInvoiceCount();
    }

    public LiveData<Double> getTotalRevenue() {
        return invoiceDao.getTotalRevenue();
    }

    private static class InsertInvoiceAsyncTask extends AsyncTask<Invoice, Void, Void> {
        private InvoiceDao invoiceDao;

        InsertInvoiceAsyncTask(InvoiceDao invoiceDao) {
            this.invoiceDao = invoiceDao;
        }

        @Override
        protected Void doInBackground(Invoice... invoices) {
            invoiceDao.insert(invoices[0]);
            return null;
        }
    }

    private static class UpdateInvoiceAsyncTask extends AsyncTask<Invoice, Void, Void> {
        private InvoiceDao invoiceDao;

        UpdateInvoiceAsyncTask(InvoiceDao invoiceDao) {
            this.invoiceDao = invoiceDao;
        }

        @Override
        protected Void doInBackground(Invoice... invoices) {
            invoiceDao.update(invoices[0]);
            return null;
        }
    }

    private static class DeleteInvoiceAsyncTask extends AsyncTask<Invoice, Void, Void> {
        private InvoiceDao invoiceDao;

        DeleteInvoiceAsyncTask(InvoiceDao invoiceDao) {
            this.invoiceDao = invoiceDao;
        }

        @Override
        protected Void doInBackground(Invoice... invoices) {
            invoiceDao.delete(invoices[0]);
            return null;
        }
    }
}

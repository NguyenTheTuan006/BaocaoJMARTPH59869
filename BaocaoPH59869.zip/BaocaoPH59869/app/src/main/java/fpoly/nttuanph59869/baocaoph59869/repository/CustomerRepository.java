package fpoly.nttuanph59869.baocaoph59869.repository;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.List;

import fpoly.nttuanph59869.baocaoph59869.dao.CustomerDao;
import fpoly.nttuanph59869.baocaoph59869.database.AppDatabase;
import fpoly.nttuanph59869.baocaoph59869.model.Customer;

public class CustomerRepository {
    private CustomerDao customerDao;
    private LiveData<List<Customer>> allCustomers;

    public CustomerRepository(Application application) {
        AppDatabase database = AppDatabase.getInstance(application);
        customerDao = database.customerDao();
        allCustomers = customerDao.getAllActiveCustomers();
    }

    public void insert(Customer customer) {
        new InsertCustomerAsyncTask(customerDao).execute(customer);
    }

    public void update(Customer customer) {
        new UpdateCustomerAsyncTask(customerDao).execute(customer);
    }

    public void delete(Customer customer) {
        new DeleteCustomerAsyncTask(customerDao).execute(customer);
    }

    public LiveData<List<Customer>> getAllCustomers() {
        return allCustomers;
    }

    public Customer getCustomerById(int id) {
        try {
            return customerDao.getCustomerById(id);
        } catch (Exception e) {
            return null;
        }
    }

    public LiveData<List<Customer>> searchCustomers(String searchQuery) {
        return customerDao.searchCustomers(searchQuery);
    }

    public LiveData<List<Customer>> searchCustomersByPhone(String phone) {
        return customerDao.searchCustomersByPhone(phone);
    }

    public LiveData<List<Customer>> getTopCustomers(int limit) {
        return customerDao.getTopCustomers(limit);
    }

    public void updateTotalSpent(int customerId, double amount) {
        new UpdateTotalSpentAsyncTask(customerDao).execute(new TotalSpentUpdate(customerId, amount));
    }

    public LiveData<Integer> getTotalCustomerCount() {
        return customerDao.getTotalCustomerCount();
    }

    private static class InsertCustomerAsyncTask extends AsyncTask<Customer, Void, Void> {
        private CustomerDao customerDao;

        InsertCustomerAsyncTask(CustomerDao customerDao) {
            this.customerDao = customerDao;
        }

        @Override
        protected Void doInBackground(Customer... customers) {
            customerDao.insert(customers[0]);
            return null;
        }
    }

    private static class UpdateCustomerAsyncTask extends AsyncTask<Customer, Void, Void> {
        private CustomerDao customerDao;

        UpdateCustomerAsyncTask(CustomerDao customerDao) {
            this.customerDao = customerDao;
        }

        @Override
        protected Void doInBackground(Customer... customers) {
            customerDao.update(customers[0]);
            return null;
        }
    }

    private static class DeleteCustomerAsyncTask extends AsyncTask<Customer, Void, Void> {
        private CustomerDao customerDao;

        DeleteCustomerAsyncTask(CustomerDao customerDao) {
            this.customerDao = customerDao;
        }

        @Override
        protected Void doInBackground(Customer... customers) {
            customerDao.delete(customers[0]);
            return null;
        }
    }

    private static class UpdateTotalSpentAsyncTask extends AsyncTask<TotalSpentUpdate, Void, Void> {
        private CustomerDao customerDao;

        UpdateTotalSpentAsyncTask(CustomerDao customerDao) {
            this.customerDao = customerDao;
        }

        @Override
        protected Void doInBackground(TotalSpentUpdate... updates) {
            TotalSpentUpdate update = updates[0];
            customerDao.updateTotalSpent(update.customerId, update.amount);
            return null;
        }
    }

    private static class TotalSpentUpdate {
        int customerId;
        double amount;

        TotalSpentUpdate(int customerId, double amount) {
            this.customerId = customerId;
            this.amount = amount;
        }
    }
}

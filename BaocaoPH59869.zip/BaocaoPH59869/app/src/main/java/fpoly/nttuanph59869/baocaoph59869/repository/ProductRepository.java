package fpoly.nttuanph59869.baocaoph59869.repository;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.List;

import fpoly.nttuanph59869.baocaoph59869.dao.ProductDao;
import fpoly.nttuanph59869.baocaoph59869.database.AppDatabase;
import fpoly.nttuanph59869.baocaoph59869.model.Product;

public class ProductRepository {
    private ProductDao productDao;
    private LiveData<List<Product>> allProducts;

    public ProductRepository(Application application) {
        AppDatabase database = AppDatabase.getInstance(application);
        productDao = database.productDao();
        allProducts = productDao.getAllActiveProducts();
    }

    public void insert(Product product) {
        new InsertProductAsyncTask(productDao).execute(product);
    }

    public void update(Product product) {
        new UpdateProductAsyncTask(productDao).execute(product);
    }

    public void delete(Product product) {
        new DeleteProductAsyncTask(productDao).execute(product);
    }

    public LiveData<List<Product>> getAllProducts() {
        return allProducts;
    }

    public LiveData<List<Product>> getProductsByCategory(int categoryId) {
        return productDao.getProductsByCategory(categoryId);
    }

    public Product getProductById(int id) {
        try {
            return productDao.getProductById(id);
        } catch (Exception e) {
            return null;
        }
    }

    public LiveData<List<Product>> searchProducts(String searchQuery) {
        return productDao.searchProducts(searchQuery);
    }

    public LiveData<List<Product>> getLowStockProducts(int threshold) {
        return productDao.getLowStockProducts(threshold);
    }

    public void updateStock(int productId, int quantity) {
        new UpdateStockAsyncTask(productDao).execute(new StockUpdate(productId, quantity));
    }

    public LiveData<List<Product>> getTopSellingProducts(int limit) {
        return productDao.getTopSellingProducts(limit);
    }

    public LiveData<Integer> getTotalProductCount() {
        return productDao.getTotalProductCount();
    }

    private static class InsertProductAsyncTask extends AsyncTask<Product, Void, Void> {
        private ProductDao productDao;

        InsertProductAsyncTask(ProductDao productDao) {
            this.productDao = productDao;
        }

        @Override
        protected Void doInBackground(Product... products) {
            productDao.insert(products[0]);
            return null;
        }
    }

    private static class UpdateProductAsyncTask extends AsyncTask<Product, Void, Void> {
        private ProductDao productDao;

        UpdateProductAsyncTask(ProductDao productDao) {
            this.productDao = productDao;
        }

        @Override
        protected Void doInBackground(Product... products) {
            productDao.update(products[0]);
            return null;
        }
    }

    private static class DeleteProductAsyncTask extends AsyncTask<Product, Void, Void> {
        private ProductDao productDao;

        DeleteProductAsyncTask(ProductDao productDao) {
            this.productDao = productDao;
        }

        @Override
        protected Void doInBackground(Product... products) {
            productDao.delete(products[0]);
            return null;
        }
    }

    private static class UpdateStockAsyncTask extends AsyncTask<StockUpdate, Void, Void> {
        private ProductDao productDao;

        UpdateStockAsyncTask(ProductDao productDao) {
            this.productDao = productDao;
        }

        @Override
        protected Void doInBackground(StockUpdate... stockUpdates) {
            StockUpdate update = stockUpdates[0];
            productDao.updateStock(update.productId, update.quantity);
            return null;
        }
    }

    private static class StockUpdate {
        int productId;
        int quantity;

        StockUpdate(int productId, int quantity) {
            this.productId = productId;
            this.quantity = quantity;
        }
    }
}

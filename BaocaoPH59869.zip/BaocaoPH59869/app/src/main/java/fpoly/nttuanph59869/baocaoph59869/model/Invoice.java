package fpoly.nttuanph59869.baocaoph59869.model;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

import java.util.Date;

@Entity(tableName = "invoices",
        foreignKeys = {
            @ForeignKey(entity = Customer.class, parentColumns = "id", childColumns = "customerId"),
            @ForeignKey(entity = User.class, parentColumns = "id", childColumns = "staffId")
        })
public class Invoice {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private String invoiceNumber;
    private int customerId;
    private int staffId;
    private Date invoiceDate;
    private double totalAmount;
    private double discount;
    private double finalAmount;
    private String paymentMethod;
    private String status; // PENDING, COMPLETED, CANCELLED
    private String notes;

    public Invoice() {
    }

    public Invoice(String invoiceNumber, int customerId, int staffId, Date invoiceDate) {
        this.invoiceNumber = invoiceNumber;
        this.customerId = customerId;
        this.staffId = staffId;
        this.invoiceDate = invoiceDate;
        this.totalAmount = 0.0;
        this.discount = 0.0;
        this.finalAmount = 0.0;
        this.paymentMethod = "Cash";
        this.status = "PENDING";
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getInvoiceNumber() {
        return invoiceNumber;
    }

    public void setInvoiceNumber(String invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public int getStaffId() {
        return staffId;
    }

    public void setStaffId(int staffId) {
        this.staffId = staffId;
    }

    public Date getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(Date invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }

    public double getFinalAmount() {
        return finalAmount;
    }

    public void setFinalAmount(double finalAmount) {
        this.finalAmount = finalAmount;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }
}
